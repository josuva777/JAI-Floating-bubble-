const bubble = document.getElementById("bubble");
const popup = document.getElementById("popup");
const sendBtn = document.getElementById("sendBtn");
const translateBtn = document.getElementById("translateBtn");
const speakBtn = document.getElementById("speakBtn");
const hearBtn = document.getElementById("hearBtn");
const themeToggle = document.getElementById("themeToggle");
const languageSelect = document.getElementById("languageSelect");
const input = document.getElementById("userInput");
const response = document.getElementById("response");

let isDragging = false;
let offsetX = 0;
let offsetY = 0;
let popupVisible = false;

// Send to Kodular
function sendToKodular(message) {
  if (window.KodularWebView && KodularWebView.postMessage) {
    KodularWebView.postMessage(message);
  }
}

// Receive voice input from Kodular
function receiveVoiceInput(text) {
  input.value = text;
  response.textContent = `You said: ${text}`;
  handleCommand();
}

// Toggle popup
bubble.addEventListener("click", () => {
  if (!isDragging) {
    popupVisible = !popupVisible;
    popup.classList.toggle("hidden", !popupVisible);
    followBubble();
  }
});

// Dragging behavior
function startDrag(e) {
  isDragging = true;
  const rect = bubble.getBoundingClientRect();
  offsetX = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
  offsetY = (e.touches ? e.touches[0].clientY : e.clientY) - rect.top;
  document.addEventListener("mousemove", onDrag);
  document.addEventListener("mouseup", stopDrag);
  document.addEventListener("touchmove", onDrag);
  document.addEventListener("touchend", stopDrag);
}

function onDrag(e) {
  if (isDragging) {
    const x = (e.touches ? e.touches[0].clientX : e.clientX) - offsetX;
    const y = (e.touches ? e.touches[0].clientY : e.clientY) - offsetY;
    bubble.style.left = `${x}px`;
    bubble.style.top = `${y}px`;
    bubble.style.right = "auto";
    bubble.style.bottom = "auto";
    followBubble();
  }
}

function stopDrag() {
  isDragging = false;
  document.removeEventListener("mousemove", onDrag);
  document.removeEventListener("mouseup", stopDrag);
  document.removeEventListener("touchmove", onDrag);
  document.removeEventListener("touchend", stopDrag);
}

bubble.addEventListener("mousedown", startDrag);
bubble.addEventListener("touchstart", startDrag);

// Align popup to bubble
function followBubble() {
  const rect = bubble.getBoundingClientRect();
  popup.style.left = `${rect.left - 10}px`;
  popup.style.top = `${rect.top - popup.offsetHeight - 10}px`;
}

// Theme toggle
themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark-theme");
  themeToggle.textContent = document.body.classList.contains("dark-theme") ? "☀️" : "🌙";
});

// Text-to-speech
hearBtn.addEventListener("click", () => {
  const lang = languageSelect.value;
  const msg = new SpeechSynthesisUtterance(response.textContent);
  msg.lang = lang;
  window.speechSynthesis.speak(msg);
});

// Mic button (starts listening from Kodular)
speakBtn.addEventListener("click", () => {
  sendToKodular("startListening");
});

// Manual translate button
translateBtn.addEventListener("click", async () => {
  const text = input.value.trim();
  const lang = languageSelect.value;
  if (!text || !lang) return;
  translateText(text, "en", lang);
});

// Main handle for both voice + text input
sendBtn.addEventListener("click", handleCommand);

// Translate function with API
async function translateText(text, fromLang, toLang) {
  try {
    const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${fromLang}|${toLang}`);
    const data = await res.json();
    response.textContent = data.responseData.translatedText;
    sendToKodular("translated:" + data.responseData.translatedText);
  } catch {
    response.textContent = "Translation failed.";
  }
}

// Command processor
function handleCommand() {
  const rawText = input.value.trim();
  const text = rawText.toLowerCase();
  if (!text) return;

  // Smart Translation: "translate how are you to tamil"
  if (text.startsWith("translate")) {
    const parts = text.match(/translate (.+?) to (\w+)/i);
    if (parts && parts[1] && parts[2]) {
      const content = parts[1];
      const target = parts[2].toLowerCase();

      const langMap = {
        tamil: "ta", hindi: "hi", english: "en", telugu: "te", malayalam: "ml",
        french: "fr", german: "de", spanish: "es", japanese: "ja", chinese: "zh-CN"
      };

      const toLang = langMap[target] || "en";
      const fromLang = "en"; // Assuming voice/text is in English

      translateText(content, fromLang, toLang);
      return;
    }
  }

  // YouTube
  if (text.includes("youtube")) {
    const query = text.replace(/.*(search|open)?\s*(on\s*)?youtube/, "").trim();
    sendToKodular("youtube:" + query);
    response.textContent = "Opening YouTube for: " + query;
    return;
  }

  // Google
  if (text.includes("google")) {
    const query = text.replace(/.*(search|open)?\s*(on\s*)?google/, "").trim();
    sendToKodular("google:" + query);
    response.textContent = "Searching Google for: " + query;
    return;
  }

  // WhatsApp
  if (text.includes("whatsapp")) {
    const message = text.replace(/.*(send|to)?\s*whatsapp/, "").trim();
    sendToKodular("whatsapp:" + message);
    response.textContent = "Sending to WhatsApp: " + message;
    return;
  }

  // Instagram
  if (text.includes("instagram")) {
    sendToKodular("instagram");
    response.textContent = "Opening Instagram...";
    return;
  }

  // Default fallback – echo/translate to self
  response.textContent = "Searching...";
  fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|en`)
    .then(res => res.json())
    .then(data => {
      response.textContent = data.responseData.translatedText;
      sendToKodular("response:" + data.responseData.translatedText);
    })
    .catch(() => {
      response.textContent = "No response.";
    });
}